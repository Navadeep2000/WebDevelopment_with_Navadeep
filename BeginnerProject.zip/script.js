function ingredientsHover() {
  document.getElementById("coffee").style.fontSize = "300%";
}

function ingredientsNormal() {
  document.getElementById("coffee").style.fontSize = "100%";
}

function preparationHover() {
  document.getElementById("book").style.fontSize = "300%";
}

function preparationNormal() {
  document.getElementById("book").style.fontSize = "100%";
}

function CopyMoveLeft() {
  document.getElementById("footer").style.textAlign = "right";
}

function CopyMoveRight() {
  document.getElementById("footer").style.textAlign = "start";
}